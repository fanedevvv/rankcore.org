'use strict';

const { MessageFlags } = require('discord.js');
const { parseEmoji }   = require('../../../Utils/emojis');

// ─────────────────────────────────────────────────────────────────────────────
// Priority metadata
// ─────────────────────────────────────────────────────────────────────────────

const PRIORITY_META = {
  low:    { label: 'Low',    slug: 'low',    emoji: parseEmoji('<:LEgreen:1395360624954839080>'), color: 0x22c55e, hex: '#22c55e' },
  medium: { label: 'Medium', slug: 'medium', emoji: parseEmoji('<:error:1395347219711918120>'),  color: 0xeab308, hex: '#eab308' },
  high:   { label: 'High',   slug: 'high',   emoji: parseEmoji('<:error:1395347219711918120>'),  color: 0xf97316, hex: '#f97316' },
  urgent: { label: 'Urgent', slug: 'urgent', emoji: parseEmoji('<:LEred:1395360626099879989>'),  color: 0xef4444, hex: '#ef4444' },
};

// IsComponentsV2 flag — tells Discord to render Components V2 layout
const CV2 = MessageFlags.IsComponentsV2;

module.exports = { PRIORITY_META, CV2 };